"""Compare a structured expected result with an actual query result.

This module is deliberately a pure comparison layer: it does not call a model
or query engine. Differences are objects so a failed comparison identifies the
protocol field, group, metric, expected value, actual value, and comparison rule.
"""

from __future__ import annotations

import json
import math
import sys
from collections import Counter
from typing import Any


STATUSES = {"ok", "clarify", "unsupported", "error"}
VERSION_FIELDS = ("data_version", "data_sha256", "catalog_sha256")
INTENT_FIELDS = {"metrics", "start", "end", "group_by", "filters"}


def _difference(
    path: str,
    expected: Any,
    actual: Any,
    rule: str,
    *,
    actual_present: bool = True,
    expected_present: bool = True,
    **extra: Any,
) -> dict[str, Any]:
    result: dict[str, Any] = {
        "path": path,
        "expected": expected,
        "actual": actual,
        "rule": rule,
    }
    if not expected_present:
        result["expected_present"] = False
    if not actual_present:
        result["actual_present"] = False
    result.update(extra)
    return result


def _is_number(value: Any) -> bool:
    return type(value) in (int, float)


def _same_value(expected: Any, actual: Any) -> bool:
    """Compare metric values as null or protocol numbers, never bool/text."""
    if expected is None or actual is None:
        return expected is None and actual is None
    if not _is_number(expected) or not _is_number(actual):
        return False
    if type(expected) is float and not math.isfinite(expected):
        return False
    if type(actual) is float and not math.isfinite(actual):
        return False
    if type(expected) is int:
        return actual == expected
    return math.isclose(expected, actual, rel_tol=1e-9, abs_tol=1e-7)


def _valid_string_list(value: Any, *, nonempty: bool) -> bool:
    return (
        isinstance(value, list)
        and (not nonempty or bool(value))
        and all(isinstance(item, str) and item for item in value)
        and len(value) == len(set(value))
    )


def _compare_unordered_names(
    expected: Any,
    actual: Any,
    path: str,
    differences: list[dict[str, Any]],
    *,
    expected_nonempty: bool = True,
) -> None:
    if not _valid_string_list(expected, nonempty=expected_nonempty):
        differences.append(
            _difference(path, expected, actual, "nonempty unique string list")
        )
        return
    if not _valid_string_list(actual, nonempty=False):
        differences.append(
            _difference(path, expected, actual, "unique string list")
        )
        return

    expected_counts = Counter(expected)
    actual_counts = Counter(actual)
    for name in sorted(expected_counts.keys() - actual_counts.keys()):
        differences.append(
            _difference(
                path,
                name,
                None,
                "missing_item",
                actual_present=False,
            )
        )
    for name in sorted(actual_counts.keys() - expected_counts.keys()):
        differences.append(
            _difference(
                path,
                None,
                name,
                "extra_item",
                expected_present=False,
            )
        )


def _normalize_filter(item: Any) -> tuple[str, str, str, Any] | None:
    if not isinstance(item, dict) or set(item) != {"field", "op", "value"}:
        return None
    field = item.get("field")
    op = item.get("op")
    value = item.get("value")
    if not isinstance(field, str) or not field:
        return None
    if op == "eq":
        if not isinstance(value, str):
            return None
        return (field, op, "eq", value)
    if op == "in":
        if not _valid_string_list(value, nonempty=True):
            return None
        return (field, op, "in", tuple(sorted(value)))
    return None


def _display_filter(item: tuple[str, str, str, Any]) -> dict[str, Any]:
    field, op, _, value = item
    return {
        "field": field,
        "op": op,
        "value": list(value) if isinstance(value, tuple) else value,
    }


def _compare_filters(
    expected: Any,
    actual: Any,
    differences: list[dict[str, Any]],
) -> None:
    path = "intent.filters"
    if not isinstance(expected, list):
        differences.append(_difference(path, expected, actual, "filter list"))
        return
    if not isinstance(actual, list):
        differences.append(_difference(path, expected, actual, "filter list"))
        return

    expected_normalized = []
    for item in expected:
        normalized = _normalize_filter(item)
        if normalized is None:
            differences.append(
                _difference(path, item, None, "invalid_expected_filter")
            )
            return
        expected_normalized.append(normalized)

    actual_normalized = []
    for item in actual:
        normalized = _normalize_filter(item)
        if normalized is None:
            differences.append(
                _difference(path, None, item, "invalid_actual_filter")
            )
            return
        actual_normalized.append(normalized)

    expected_counts = Counter(expected_normalized)
    actual_counts = Counter(actual_normalized)
    if len(expected_normalized) != len(expected_counts):
        differences.append(
            _difference(path, expected, actual, "duplicate_expected_filter")
        )
    if len(actual_normalized) != len(actual_counts):
        differences.append(
            _difference(path, expected, actual, "duplicate_actual_filter")
        )
    for item in sorted(expected_counts.keys() - actual_counts.keys()):
        differences.append(
            _difference(
                path,
                _display_filter(item),
                None,
                "missing_filter",
                actual_present=False,
            )
        )
    for item in sorted(actual_counts.keys() - expected_counts.keys()):
        differences.append(
            _difference(
                path,
                None,
                _display_filter(item),
                "extra_filter",
                expected_present=False,
            )
        )


def _compare_intent(
    expected: Any,
    actual: Any,
    differences: list[dict[str, Any]],
) -> None:
    if not isinstance(expected, dict):
        differences.append(_difference("intent", expected, actual, "object"))
        return
    if not isinstance(actual, dict):
        differences.append(_difference("intent", expected, actual, "object"))
        return

    expected_keys = set(expected)
    actual_keys = set(actual)
    if expected_keys != INTENT_FIELDS:
        differences.append(
            _difference(
                "intent.keys",
                sorted(INTENT_FIELDS),
                sorted(expected_keys, key=repr),
                "expected_intent_fields",
            )
        )
    if actual_keys != INTENT_FIELDS:
        differences.append(
            _difference(
                "intent.keys",
                sorted(INTENT_FIELDS),
                sorted(actual_keys, key=repr),
                "actual_intent_fields",
            )
        )

    _compare_unordered_names(
        expected.get("metrics"), actual.get("metrics"), "intent.metrics", differences
    )
    for field in ("start", "end"):
        if expected.get(field) != actual.get(field):
            differences.append(
                _difference(
                    f"intent.{field}",
                    expected.get(field),
                    actual.get(field),
                    "exact",
                    actual_present=field in actual,
                    expected_present=field in expected,
                )
            )
    _compare_unordered_names(
        expected.get("group_by"),
        actual.get("group_by"),
        "intent.group_by",
        differences,
        expected_nonempty=False,
    )
    _compare_filters(expected.get("filters"), actual.get("filters"), differences)


def _compare_units(
    expected: Any,
    actual: Any,
    metrics: Any,
    differences: list[dict[str, Any]],
) -> None:
    path = "units"
    if not isinstance(expected, dict):
        differences.append(_difference(path, expected, actual, "object"))
        return
    if not isinstance(actual, dict):
        differences.append(_difference(path, expected, actual, "object"))
        return
    if _valid_string_list(metrics, nonempty=True):
        expected_metrics = set(metrics)
        for side, units in (("expected", expected), ("actual", actual)):
            if set(units) != expected_metrics:
                differences.append(
                    _difference(
                        path,
                        sorted(expected_metrics),
                        sorted(units, key=repr),
                        f"{side}_metric_units",
                    )
                )
    for metric in sorted(set(expected) | set(actual), key=repr):
        if metric not in actual:
            differences.append(
                _difference(
                    f"{path}.{metric}",
                    expected[metric],
                    None,
                    "exact",
                    actual_present=False,
                )
            )
        elif metric not in expected:
            differences.append(
                _difference(
                    f"{path}.{metric}",
                    None,
                    actual[metric],
                    "exact",
                    expected_present=False,
                )
            )
        elif expected[metric] != actual[metric]:
            differences.append(
                _difference(
                    f"{path}.{metric}",
                    expected[metric],
                    actual[metric],
                    "exact",
                )
            )


def _column_shape(
    columns: Any,
    rows: Any,
    side: str,
    differences: list[dict[str, Any]],
) -> bool:
    if not _valid_string_list(columns, nonempty=True):
        differences.append(
            _difference("columns", columns, None, f"{side}_column_list")
        )
        return False
    if not isinstance(rows, list):
        differences.append(_difference("rows", rows, None, f"{side}_row_list"))
        return False
    valid = True
    for index, row in enumerate(rows):
        if not isinstance(row, list) or len(row) != len(columns):
            differences.append(
                _difference(
                    f"rows[{index}]",
                    len(columns),
                    len(row) if isinstance(row, list) else row,
                    f"{side}_row_length",
                )
            )
            valid = False
    return valid


def _compare_columns(
    expected: dict[str, Any],
    actual: dict[str, Any],
    differences: list[dict[str, Any]],
) -> bool:
    expected_ok = _column_shape(
        expected.get("columns"), expected.get("rows"), "expected", differences
    )
    actual_ok = _column_shape(
        actual.get("columns"), actual.get("rows"), "actual", differences
    )
    if not isinstance(expected.get("columns"), list) or not isinstance(
        actual.get("columns"), list
    ):
        return False

    expected_columns = expected["columns"]
    actual_columns = actual["columns"]
    if not _valid_string_list(expected_columns, nonempty=True) or not _valid_string_list(
        actual_columns, nonempty=True
    ):
        return False
    if len(expected_columns) != len(set(expected_columns)) or len(
        actual_columns
    ) != len(set(actual_columns)):
        differences.append(
            _difference(
                "columns",
                expected_columns,
                actual_columns,
                "unique_column_names",
            )
        )
        return False
    for name in expected_columns:
        if name not in actual_columns:
            differences.append(
                _difference(
                    "columns",
                    name,
                    None,
                    "missing_column",
                    actual_present=False,
                )
            )
    for name in actual_columns:
        if name not in expected_columns:
            differences.append(
                _difference(
                    "columns",
                    None,
                    name,
                    "extra_column",
                    expected_present=False,
                )
            )

    intent = expected.get("intent")
    if isinstance(intent, dict) and _valid_string_list(
        intent.get("metrics"), nonempty=True
    ) and _valid_string_list(intent.get("group_by"), nonempty=False):
        expected_layout = set(intent["group_by"]) | set(intent["metrics"])
        for side, columns in (
            ("expected", expected_columns),
            ("actual", actual_columns),
        ):
            if set(columns) != expected_layout:
                differences.append(
                    _difference(
                        "columns",
                        sorted(expected_layout),
                        sorted(columns),
                        f"{side}_metric_dimension_layout",
                    )
                )

    return expected_ok and actual_ok and set(expected_columns) == set(actual_columns)


def _row_groups(
    rows: list[list[Any]],
    columns: list[str],
    group_by: list[str],
    side: str,
    differences: list[dict[str, Any]],
) -> dict[tuple[Any, ...], dict[str, Any]]:
    grouped: dict[tuple[Any, ...], dict[str, Any]] = {}
    group_positions = [columns.index(name) for name in group_by]
    for index, row in enumerate(rows):
        key = tuple(row[position] for position in group_positions)
        if not all(isinstance(value, str) for value in key):
            differences.append(
                _difference(
                    f"rows[{index}]",
                    "string group values",
                    key,
                    f"{side}_group_key_type",
                )
            )
            continue
        try:
            hash(key)
        except TypeError:
            differences.append(
                _difference(
                    f"rows[{index}]",
                    "hashable group key",
                    key,
                    f"{side}_group_key",
                )
            )
            continue
        if key in grouped:
            differences.append(
                _difference(
                    "rows",
                    None,
                    dict(zip(group_by, key)),
                    f"duplicate_{side}_group",
                    expected_present=False,
                )
            )
            continue
        grouped[key] = dict(zip(columns, row))
    return grouped


def _compare_values(
    expected: dict[str, Any],
    actual: dict[str, Any],
    differences: list[dict[str, Any]],
) -> None:
    intent = expected["intent"]
    metrics = intent["metrics"]
    group_by = intent["group_by"]
    expected_columns = expected["columns"]
    actual_columns = actual["columns"]

    if not group_by:
        if len(expected["rows"]) != 1:
            differences.append(
                _difference(
                    "rows",
                    1,
                    len(expected["rows"]),
                    "expected_single_ungrouped_row",
                )
            )
            return
        if len(actual["rows"]) != 1:
            differences.append(
                _difference(
                    "rows",
                    1,
                    len(actual["rows"]),
                    "actual_single_ungrouped_row",
                )
            )
            return
        expected_groups = {(): dict(zip(expected_columns, expected["rows"][0]))}
        actual_groups = {(): dict(zip(actual_columns, actual["rows"][0]))}
    else:
        if any(name not in expected_columns for name in group_by) or any(
            name not in actual_columns for name in group_by
        ):
            return
        expected_groups = _row_groups(
            expected["rows"], expected_columns, group_by, "expected", differences
        )
        actual_groups = _row_groups(
            actual["rows"], actual_columns, group_by, "actual", differences
        )

    for key in sorted(expected_groups.keys() - actual_groups.keys(), key=repr):
        differences.append(
            _difference(
                "rows",
                dict(zip(group_by, key)),
                None,
                "missing_group",
                actual_present=False,
            )
        )
    for key in sorted(actual_groups.keys() - expected_groups.keys(), key=repr):
        differences.append(
            _difference(
                "rows",
                None,
                dict(zip(group_by, key)),
                "extra_group",
                expected_present=False,
            )
        )

    for key in sorted(expected_groups.keys() & actual_groups.keys(), key=repr):
        expected_row = expected_groups[key]
        actual_row = actual_groups[key]
        group = dict(zip(group_by, key))
        for metric in metrics:
            if metric not in expected_row or metric not in actual_row:
                continue
            expected_value = expected_row[metric]
            actual_value = actual_row[metric]
            if _same_value(expected_value, actual_value):
                continue
            rule = (
                "exact_integer"
                if type(expected_value) is int
                else "relative_1e-9_absolute_1e-7"
                if type(expected_value) is float
                else "exact_or_null"
            )
            differences.append(
                _difference(
                    "rows",
                    expected_value,
                    actual_value,
                    rule,
                    group=group,
                    metric=metric,
                )
            )


def compare(expected: Any, actual: Any) -> dict[str, Any]:
    """Return ``passed`` and a list of protocol-level differences."""
    differences: list[dict[str, Any]] = []
    if not isinstance(expected, dict):
        differences.append(_difference("expected", expected, actual, "object"))
        return {"passed": False, "differences": differences}
    if not isinstance(actual, dict):
        differences.append(_difference("actual", expected, actual, "object"))
        return {"passed": False, "differences": differences}

    expected_status = expected.get("status")
    if expected_status not in STATUSES:
        differences.append(
            _difference(
                "status", expected_status, actual.get("status"), "supported_status"
            )
        )
        return {"passed": False, "differences": differences}
    actual_status = actual.get("status")
    if actual_status != expected_status:
        differences.append(
            _difference("status", expected_status, actual_status, "exact")
        )
        return {"passed": False, "differences": differences}

    for field in VERSION_FIELDS:
        if field not in expected:
            continue
        if field not in actual:
            differences.append(
                _difference(
                    field,
                    expected[field],
                    None,
                    "exact",
                    actual_present=False,
                )
            )
        elif expected[field] != actual[field]:
            differences.append(
                _difference(field, expected[field], actual[field], "exact")
            )

    if expected_status != "ok":
        return {"passed": not differences, "differences": differences}

    intent = expected.get("intent")
    metrics = intent.get("metrics") if isinstance(intent, dict) else None
    _compare_intent(intent, actual.get("intent"), differences)
    _compare_units(expected.get("units"), actual.get("units"), metrics, differences)
    columns_ok = _compare_columns(expected, actual, differences)
    if columns_ok and isinstance(intent, dict):
        if (
            _valid_string_list(intent.get("metrics"), nonempty=True)
            and _valid_string_list(intent.get("group_by"), nonempty=False)
            and isinstance(expected.get("columns"), list)
            and isinstance(actual.get("columns"), list)
            and isinstance(expected.get("rows"), list)
            and isinstance(actual.get("rows"), list)
        ):
            _compare_values(expected, actual, differences)

    return {"passed": not differences, "differences": differences}


def main() -> None:
    try:
        payload = json.load(sys.stdin)
        result = compare(payload["expected"], payload["actual"])
    except Exception as exc:  # Keep stdout reserved for the comparison object.
        print(f"judge input error: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
