#!/usr/bin/env python3
"""Independently audit the small-sample expectations from the source CSVs.

This program intentionally uses only the Python standard library and the four
source CSV files. It does not import the metrics library, SQL models, or query
engine. Its purpose is to catch transcription and definition errors in
``tests.json`` before the Agent is run.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from collections import defaultdict
from datetime import date
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "materials/data/small"
TESTS = ROOT / "customer/w03/tests.json"
TARGETS = ROOT / "customer/w03/targets.json"


def read_csv(name: str) -> list[dict[str, str]]:
    with (DATA / name).open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def in_window(row: dict[str, str], start: date, end: date) -> bool:
    ordered_at = date.fromisoformat(row["ordered_at"])
    return start <= ordered_at < end


def is_paid(row: dict[str, str]) -> bool:
    return row["status"] == "paid"


def is_valid(row: dict[str, str]) -> bool:
    return (
        is_paid(row)
        and int(row["paid_cents"]) - int(row["refund_cents"]) > 0
    )


def source_rows(
    orders: list[dict[str, str]],
    start: date,
    end: date,
    *,
    valid_only: bool = False,
    channel: str | None = None,
) -> list[dict[str, str]]:
    rows = [row for row in orders if in_window(row, start, end)]
    if valid_only:
        rows = [row for row in rows if is_valid(row)]
    if channel is not None:
        rows = [row for row in rows if row["channel"] == channel]
    return rows


def safe_ratio(numerator: int | float, denominator: int | float) -> float | None:
    return None if denominator == 0 else numerator / denominator


def compute_orders(rows: list[dict[str, str]]) -> dict[str, Any]:
    paid = [row for row in rows if is_paid(row)]
    valid = [row for row in rows if is_valid(row)]
    refunded = [
        row for row in paid if int(row["refund_cents"]) > 0
    ]
    partial = [
        row
        for row in refunded
        if int(row["refund_cents"]) < int(row["paid_cents"])
    ]
    full = [
        row
        for row in paid
        if int(row["paid_cents"]) > 0
        and int(row["refund_cents"]) == int(row["paid_cents"])
    ]
    payment = sum(int(row["paid_cents"]) for row in paid)
    refund = sum(int(row["refund_cents"]) for row in paid)
    gross = sum(int(row["gross_cents"]) for row in paid)
    discount = sum(
        int(row["gross_cents"]) - int(row["paid_cents"]) for row in paid
    )
    return {
        "order_count": len(rows),
        "paid_order_count": len(paid),
        "valid_order_count": len(valid),
        "cancelled_order_count": len(
            [row for row in rows if row["status"] == "cancelled"]
        ),
        "refund_order_count": len(refunded),
        "partial_refund_order_count": len(partial),
        "full_refund_order_count": len(full),
        "payment_cents": payment,
        "refund_cents": refund,
        "net_sales_cents": payment - refund,
        "gross_cents": gross,
        "discount_cents": discount,
        "buyer_count": len({row["member_id"] for row in valid}),
        "refund_buyer_count": len(
            {row["member_id"] for row in refunded}
        ),
        "selling_store_count": len({row["store_id"] for row in valid}),
        "valid_order_items": sum(int(row["quantity"]) for row in valid),
    }


def compute_ratios(values: dict[str, Any]) -> dict[str, float | None]:
    return {
        "avg_order_value": safe_ratio(
            values["net_sales_cents"], values["valid_order_count"]
        ),
        "avg_buyer_value": safe_ratio(
            values["net_sales_cents"], values["buyer_count"]
        ),
        "purchase_frequency": safe_ratio(
            values["valid_order_count"], values["buyer_count"]
        ),
        "refund_amount_rate": safe_ratio(
            values["refund_cents"], values["payment_cents"]
        ),
        "cancel_rate": safe_ratio(
            values["cancelled_order_count"], values["order_count"]
        ),
        "refund_order_rate": safe_ratio(
            values["refund_order_count"], values["paid_order_count"]
        ),
        "discount_rate": safe_ratio(
            values["discount_cents"], values["gross_cents"]
        ),
        "items_per_order": safe_ratio(
            values["valid_order_items"], values["valid_order_count"]
        ),
    }


def compute_observed_first_orders(
    orders: list[dict[str, str]], start: date, end: date
) -> tuple[int, int, int, int]:
    ranks: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in orders:
        if is_valid(row):
            ranks[row["member_id"]].append(row)
    first: list[dict[str, str]] = []
    repeat: list[dict[str, str]] = []
    for rows in ranks.values():
        ordered = sorted(
            rows, key=lambda row: (row["ordered_at"], row["order_id"])
        )
        first.append(ordered[0])
        repeat.extend(ordered[1:])
    first_in_window = [row for row in first if in_window(row, start, end)]
    repeat_in_window = [row for row in repeat if in_window(row, start, end)]
    return (
        len({row["member_id"] for row in first_in_window}),
        sum(
            int(row["paid_cents"]) - int(row["refund_cents"])
            for row in first_in_window
        ),
        len(first_in_window),
        len(repeat_in_window),
    )


def compute_monthly_activity(
    orders: list[dict[str, str]], month_start: date, month_end: date
) -> tuple[int, int, float | None]:
    order_counts: dict[str, int] = defaultdict(int)
    for row in source_rows(orders, month_start, month_end, valid_only=True):
        order_counts[row["member_id"]] += 1
    buyers = len(order_counts)
    repeat = sum(count >= 2 for count in order_counts.values())
    return buyers, repeat, safe_ratio(repeat, buyers)


def compute_monthly_paid(
    orders: list[dict[str, str]],
    cards: list[dict[str, str]],
    month_start: date,
    month_end: date,
) -> tuple[int, int, int, int, float | None, float | None]:
    month_end_inclusive = date.fromordinal(month_end.toordinal() - 1)
    included_types = {"悦享年卡", "家庭季卡"}
    qualified: set[str] = set()
    for card in cards:
        if card["card_type"] not in included_types:
            continue
        valid_from = date.fromisoformat(card["valid_from"])
        valid_until = date.fromisoformat(card["valid_until"])
        ended_at = (
            date.fromisoformat(card["ended_at"])
            if card["ended_at"]
            else None
        )
        if (
            valid_from <= month_end_inclusive
            and valid_until > month_end_inclusive
            and (ended_at is None or ended_at > month_end_inclusive)
        ):
            qualified.add(card["member_id"])

    valid_orders = [
        row
        for row in source_rows(orders, month_start, month_end, valid_only=True)
        if row["member_id"] in qualified
    ]
    per_member: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in valid_orders:
        per_member[row["member_id"]].append(row)
    buyer_count = len(per_member)
    order_count = len(valid_orders)
    sales = sum(
        int(row["paid_cents"]) - int(row["refund_cents"])
        for row in valid_orders
    )
    repeat = sum(len(rows) >= 2 for rows in per_member.values())
    return (
        buyer_count,
        order_count,
        sales,
        repeat,
        safe_ratio(repeat, buyer_count),
        safe_ratio(sales, order_count),
    )


def value_equal(expected: Any, actual: Any) -> bool:
    if expected is None or actual is None:
        return expected is None and actual is None
    if type(expected) in (int, float) and type(actual) in (int, float):
        if isinstance(expected, int):
            return actual == expected
        return math.isclose(expected, actual, rel_tol=1e-12, abs_tol=1e-12)
    return expected == actual


def row_equal(expected: list[Any], actual: list[Any]) -> bool:
    return len(expected) == len(actual) and all(
        value_equal(want, got) for want, got in zip(expected, actual)
    )


def expected_grid(
    case: dict[str, Any],
) -> tuple[list[str], list[list[Any]], dict[str, str]]:
    expected = case["expected"]
    return expected["columns"], expected["rows"], expected["units"]


def build_independent_expectations() -> dict[str, Any]:
    orders = read_csv("orders.csv")
    members = read_csv("members.csv")
    cards = read_csv("cards.csv")
    august_start = date(2026, 8, 1)
    september_start = date(2026, 9, 1)
    august = source_rows(orders, august_start, september_start)
    august_values = compute_orders(august)
    august_ratios = compute_ratios(august_values)
    store_rows: dict[str, int] = defaultdict(int)
    for row in source_rows(
        orders, august_start, september_start, valid_only=True
    ):
        store_rows[row["store_id"]] += 1
    channel_values = compute_orders(
        source_rows(
            orders,
            august_start,
            september_start,
            channel="门店",
        )
    )
    first = compute_observed_first_orders(
        orders, august_start, september_start
    )
    monthly = compute_monthly_activity(
        orders, august_start, september_start
    )
    monthly_paid = compute_monthly_paid(
        orders,
        cards,
        august_start,
        september_start,
    )
    new_member_count = len(
        [
            member
            for member in members
            if date(2026, 7, 1)
            <= date.fromisoformat(member["registered_at"])
            < august_start
        ]
    )
    empty_rate = safe_ratio(
        compute_orders(
            source_rows(
                orders,
                date(2024, 10, 1),
                date(2024, 11, 1),
            )
        )["refund_cents"],
        compute_orders(
            source_rows(
                orders,
                date(2024, 10, 1),
                date(2024, 11, 1),
            )
        )["payment_cents"],
    )
    return {
        "order-counts-2026-08": [
            [
                august_values[name]
                for name in (
                    "order_count",
                    "paid_order_count",
                    "valid_order_count",
                    "cancelled_order_count",
                    "refund_order_count",
                    "partial_refund_order_count",
                    "full_refund_order_count",
                )
            ]
        ],
        "amounts-2026-08": [
            [
                august_values[name]
                for name in (
                    "payment_cents",
                    "refund_cents",
                    "net_sales_cents",
                    "gross_cents",
                    "discount_cents",
                )
            ]
        ],
        "buyers-stores-items-2026-08": [
            [
                august_values[name]
                for name in (
                    "buyer_count",
                    "refund_buyer_count",
                    "selling_store_count",
                    "valid_order_items",
                )
            ]
        ],
        "ratios-2026-08": [
            [
                august_ratios[name]
                for name in (
                    "avg_order_value",
                    "avg_buyer_value",
                    "purchase_frequency",
                    "refund_amount_rate",
                    "cancel_rate",
                    "refund_order_rate",
                    "discount_rate",
                    "items_per_order",
                )
            ]
        ],
        "new-members-2026-07": [[new_member_count]],
        "first-and-repeat-2026-08": [list(first)],
        "monthly-activity-2026-08": [list(monthly)],
        "monthly-paid-members-2026-08": [list(monthly_paid)],
        "valid-orders-by-store-2026-08": [
            [store, store_rows[store]] for store in sorted(store_rows)
        ],
        "store-channel-net-sales-2026-08": [
            [channel_values["net_sales_cents"]]
        ],
        "empty-window-refund-rate-null": [[empty_rate]],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output")
    args = parser.parse_args()

    cases = json.loads(TESTS.read_text(encoding="utf-8"))
    targets = json.loads(TARGETS.read_text(encoding="utf-8"))
    computed = build_independent_expectations()
    expected_status = {
        "needs-period": "clarify",
        "outside-coverage-2026-09": "unsupported",
        "partial-month-activity": "unsupported",
    }
    covered_metrics = {
        metric
        for case in cases
        for metric in case["expected"].get("intent", {}).get("metrics", [])
    }
    target_metrics = {target["id"] for target in targets}
    results = []
    for case in cases:
        case_id = case["id"]
        if case_id in expected_status:
            passed = case["expected"].get("status") == expected_status[case_id]
            differences = [] if passed else ["unexpected non-ok status"]
        elif case_id in computed:
            _, rows, _ = expected_grid(case)
            independent_rows = computed[case_id]
            differences = []
            if len(rows) != len(independent_rows):
                differences.append(
                    f"row count: expected {len(rows)}, audit {len(independent_rows)}"
                )
            else:
                for index, (want, got) in enumerate(zip(rows, independent_rows)):
                    if not row_equal(want, got):
                        differences.append(
                            f"row {index}: expected {want}, audit {got}"
                        )
            passed = not differences
        else:
            passed = False
            differences = ["case has no independent audit rule"]
        results.append(
            {"id": case_id, "passed": passed, "differences": differences}
        )

    report = {
        "source": "materials/data/small/*.csv",
        "metrics_library_used": False,
        "passed": sum(result["passed"] for result in results),
        "total": len(results),
        "all_target_metrics_covered": target_metrics <= covered_metrics,
        "missing_target_metrics": sorted(target_metrics - covered_metrics),
        "cases": results,
    }
    rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        output = Path(args.output)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    raise SystemExit(
        0
        if report["passed"] == report["total"]
        and report["all_target_metrics_covered"]
        else 1
    )


if __name__ == "__main__":
    main()
