# 指标核定与未决项

## 采用依据

核定对象为当前 [build-v1](/Users/dodo/fde/W03/工程/fde-agent-w03/artifacts/w03/build-v1/) 中的 [catalog.json](/Users/dodo/fde/W03/工程/fde-agent-w03/artifacts/w03/build-v1/catalog.json)、[metrics.yml](/Users/dodo/fde/W03/工程/fde-agent-w03/artifacts/w03/build-v1/metrics.yml) 和派生 SQL。该版 `source_check.json` 已通过，`dimension_check.json`、`grain_check.json`、`metricflow_check.json` 和 `validation.json` 均显示通过；这些检查只证明已定义部分的结构、引文和原生编译成立，不代表未决项已获客户确认，也不代替独立数值核对。

所有采用项适用于 `materials/w03/05_数据字典.md` 声明的合成测试范围：`2024-09-01`（包含）至 `2026-09-01`（不包含），`Asia/Shanghai`，日期粒度；不代表生产全量。订单按原订单下单日期归期，退款按原订单日期归属；金额底层单位为整数分，展示元需换算。账户是 CRM 会员账户，不跨系统合并自然人。

- 订单计数族（`order_count`、`paid_order_count`、`valid_order_count`、`cancelled_order_count`、`refund_order_count`、`partial_refund_order_count`、`full_refund_order_count`）：采用 `materials/w03/01_订单日报说明.md` 的当前测试口径，按 `ordered_at` 归期、按订单号计一次；创建单包含取消单，支付单包含后续全退单，有效单要求 paid 且实付减累计退款大于零，取消和全退不计。来源：“按下单日期统计全部订单，每个订单号一次，包含取消单。”“状态为 paid 且实付金额减退款金额大于零的订单数；取消和全退不计。”
- 金额族（`payment_cents`、`refund_cents`、`net_sales_cents`、`gross_cents`、`discount_cents`）：采用 `materials/w03/01_订单日报说明.md` 与 `materials/w03/02_财务邮件.md` 的当前测试口径；实付不扣退款，退款按原订单日期归属且不冲减优惠，净销售额为 paid 订单实付减退款，金额为整数分。来源：“退款按原订单日期归属。金额为整数分，展示元需换算。”以及“paid 订单实付减退款后合计；取消单不计；按原订单下单日期归属；单位分。”
- 对象去重族（`buyer_count`、`refund_buyer_count`、`selling_store_count`、`valid_order_items`）：采用 `materials/w03/01_订单日报说明.md` 的当前测试口径；购买会员按有效订单关联的不同 CRM 账户去重，退款会员按退款大于零的 paid 订单关联账户去重，成交门店按有效订单的门店去重；商品件数为有效订单原始件数合计，不是净销量。来源：“统计窗口及筛选条件内有有效订单的不同 CRM 会员账户数，不做跨系统自然人去重。”“有效订单中的原始购买件数合计；退款金额不能推算退货件数，此项不是净商品销量。”
- 比率族（`avg_order_value`、`avg_buyer_value`、`purchase_frequency`、`refund_amount_rate`、`cancel_rate`、`refund_order_rate`、`discount_rate`、`items_per_order`）：采用 `materials/w03/02_财务邮件.md` 的已列分子、分母和单位；零分母保留为未定义，不填零。`metrics.yml` 中的 ratio 均引用这些已定义指标。来源：“净销售额除以有效订单数，单位分／单；分母零时未定义。”及各目标的财务邮件对应句。
- 注册会员数（`new_member_count`）：采用 `materials/w03/03_会员运营周报.md` 的当前测试口径，按 CRM 账户注册日期统计，可按归属门店和会员等级分组，不等于自然人数。来源：“按注册日期统计新注册 CRM 账户数；可按归属门店和会员等级分组，不等于自然人数。”

上述 25 项已写入 build-v1 的 `metrics.yml` 和 `catalog.json`，目录中的引文与 `source_check` 校验通过。W03 材料已明确的其余 7 项目标因当前构建未接通派生语义模型而暂不支持，不能把 `unresolved` 中的“缺派生模型”误写成客户没有定义。

## 冲突、未决与不支持

- 首购与后续购买族（`first_buyer_count`、`first_order_sales_cents`、`first_order_count`、`repeat_order_count`）：材料已明确先在全测试覆盖历史上按有效订单日期、订单号排序，再把第一笔或第二笔以后的结果按查询窗口筛选；当前 build-v1 生成了 `account_order_history.sql`，但没有把该派生模型注册为语义模型和指标，故四项均在 `unresolved.json` 中。影响：首购人数、首单数、首单净销售额和后续购买订单数不可查询。状态：暂不支持，属构建实现缺口而非客户定义缺口。下一步：回到第 6 步修正派生语义模型的指标依赖，再用新构建目录生成并检查。
- 月内购买与复购族（`monthly_buyer_count`、`monthly_repeat_buyer_count`、`monthly_repeat_rate`）：`materials/w03/03_会员运营周报.md` 已明确在同一自然月的完整月份内，按账户是否有一笔或至少两笔有效订单判断购买/复购，并按账户×月先收敛；当前 build-v1 虽生成 `account_monthly_activity.sql`，但没有注册对应语义模型和三个目标指标。影响：月内购买人数、复购人数和复购率不可查询。状态：暂不支持，属构建实现缺口；规则本身不再向客户重问。下一步：按账户×月粒度接通派生模型，并设置 `full_month_only: true` 后重新构建。
- 月末付费会员六项（`monthly_paid_buyer_count`、`monthly_paid_order_count`、`monthly_paid_sales_cents`、`monthly_paid_repeat_buyer_count`、`monthly_paid_repeat_rate`、`monthly_paid_avg_order_value`）：采用王经理所述的本期统计选择：先按自然月最后一天确定账户付费资格，再统计这些账户当月全渠道、全门店的有效订单；不要求订单当天已具资格，按账户去重，不按卡名、当前权益状态或持卡张数直接判断。来源：`W3-interview-wang01-transcript.json` 的 MSG-03518、MSG-03520、MSG-03522、MSG-03526、MSG-03528；FDE 采用该客户陈述，但这不是成文制度。影响：在资格映射确定前无法形成六项指标的合格账户总体，因而人数、订单数、销售额、复购及均额均不可查询。状态：真实未决，当前 build-v1 未定义。下一步：小林按实际资格记录给出四类 `card_type` 纳入清单；老周给 `valid_from`/`valid_until`/`ended_at` 端点解释、字段覆盖及多卡账户的月末资格记录；运营与门店说法不一致时由小林协调。王经理只复核统计口径，不拍板。
- 维度冗余记录：`unresolved.json` 还有 `store__region`、`store__store_name`、`home_store__region`、`home_store__store_name` 四条“需确认关联路径”。这不是新的客户缺口：`materials/w03/05_数据字典.md` 已写明订单和会员归属门店均关联同一门店主键，当前 `dimension_check.json` 也把 12 个维度全部判为可查询。状态：冗余元数据，不影响当前可查询库；下一步在再次构建时清理，不向客户重问。
- 无其他已发现的口径冲突。W02 对长期复购率/取数方式的未知保留为更泛的业务未知，但不覆盖 `materials/w03/03_会员运营周报.md` 已明确的 `monthly_repeat_rate` 当前公式。程序检查通过不等于业务数值已验证；尤其首购历史排序、月度账户粒度、退款归期和月底资格仍需按独立查询场景核对。

## 解释人工核查

本节以 `artifacts/w03/test-small-v1` 中已有真实 trace 为解释证据；`test-small-v2` 因模型端点 DNS 不通，所有用例均停在意图调用前，没有新增可核查解释。独立期望由 `customer/w03/independent_audit.py` 直接读取四份小样本 CSV 重算，不导入指标库、不调用指标 SQL；结果为 14/14 用例的期望数值一致，覆盖全部 38 个目标指标。

| 用例 | 客户是否正确 | 时间、筛选、口径说得对吗 | 有没有把已知说成未知 | 结论 |
| --- | --- | --- | --- | --- |
| `order-counts-2026-08` | 是，32/30/27/2/4/1/3 与独立核算一致 | 说明了下单日期归月、退款归原订单月份、有效单和取消/全退排除；无筛选、无分组 | 否 | 通过 |
| `amounts-2026-08` | 是，金额与独立核算一致，分和元换算正确 | 说明了 paid、退款归期、净额扣减及优惠不因退款冲减；无筛选、无分组 | 否 | 通过 |
| `buyers-stores-items-2026-08` | 是，15/4/2/33 与独立核算一致 | 说明 CRM 账户去重、成交门店而非归属门店、原始件数而非净销量；无筛选、无分组 | 否 | 通过 |
| `ratios-2026-08` | 无回答，不能判定 | 本次在意图调用即遇 `MODEL_NETWORK_ERROR`，没有产生时间、筛选或口径解释 | 未产生解释 | 要修 |
| `new-members-2026-07` | 是，12 个与独立核算一致 | 说明了 7 月完整自然月、按 `registered_at` 统计且账户不等于自然人；无筛选、无分组 | 否 | 通过 |
| `first-and-repeat-2026-08` | 是，5/12800/5/22 与独立核算一致 | 说明了先在全覆盖历史按账户确定首单及后续单，再筛 8 月；无筛选、无分组 | 否 | 通过 |
| `monthly-activity-2026-08` | 是，15/12/0.8 与独立核算一致 | 说明了完整自然月、同一账户月内至少两笔、全门店全渠道，并把比率解释为 80% | 否 | 通过 |
| `monthly-paid-members-2026-08` | 数值 6/10/47550/4/0.6666666666666666/4755 与独立核算一致 | 解释了月末资格、整月全渠道全门店、净额和复购率；未明确写出纳入卡种及 `valid_until`/`ended_at` 端点，口径说明不够完整 | 否 | 要修 |
| `valid-orders-by-store-2026-08` | 是，S01=13、S02=14 与独立核算一致 | 说明了有效订单条件、按成交门店分组；没有把未出现的 S03 断言为零 | 否 | 通过 |
| `store-channel-net-sales-2026-08` | v1 无数值答案；原问句“门店渠道”确有歧义，当前问句尚未得到新回答 | v1 合理返回澄清，未擅自选渠道；现已改成“订单渠道为门店”，待真实回归 | v1 把歧义识别为未知，处理合理 | 要修 |
| `empty-window-refund-rate-null` | 是，该月无订单、分母为零，返回 `null` | 说明了 2024 年 10 月、按原订单日期归期及零分母未定义 | 否，明确保留未知 | 通过 |
| `needs-period` | 是，没有编造时间结果 | 因缺必要时间范围返回 `clarify`，说明需补起止日期 | 否，明确保留未知 | 通过 |
| `outside-coverage-2026-09` | 是，没有把覆盖外返回为零 | 说明覆盖截至 2026-09-01（不含），2026 年 9 月整月不支持 | 否，明确保留未知 | 通过 |
| `partial-month-activity` | 是，没有误算半月月内复购 | 说明该指标只支持完整自然月，8 月 1 日至 20 日返回不支持 | 否，明确保留未知 | 通过 |

`monthly-paid-members-2026-08` 的数值正确，但客户解释没有把资格卡种和日期端点完整说清，因此不能仅凭机器 `passed` 判为客户解释通过。`ratios-2026-08` 和当前 `store-channel-net-sales-2026-08` 仍需在模型网络恢复后重跑并复核解释。

## 测试与回归记录

| 轮次 | 报告目录 | 失败现象 | 错误来源 | 改了什么 | 回归结果 |
| --- | --- | --- | --- | --- | --- |
| 独立期望审计 | `artifacts/w03/independent-audit-v1.json` | 无 | 无 | 新增仅用标准库和 CSV 的独立审核程序 | 14/14 用例通过，38/38 目标指标均有成功用例覆盖 |
| 判定自检 | `artifacts/w03/judge-check-report.json` | 无 | 无 | 从已核对真实结果制作 13 份输入，其中 11 份各注入一处错误 | 原始正确结果和仅换行序通过；错指标、错日期、多筛选、漏组、重复组、错单位、比例当百分数、null 改零、篡改数值、error 伪装和错版本全部被拒 |
| 第 1 轮 | `artifacts/w03/test-small-v1` | 12/14 通过；比例组模型调用失败，门店渠道问句被合理澄清 | 模型；期望中的问句表述有歧义 | 未改期望迎合实际；把渠道问句明确为“订单渠道为门店” | 需重跑；不能以 12/14 或退出码算完成 |
| 第 2 轮 | `artifacts/w03/test-small-v2` | 0/14；14 条均报 `MODEL_NETWORK_ERROR`，每条约 0.03 秒且 `model_calls_with_usage` 为 0 | 模型网络：`api.deepseek.com` DNS 解析失败 | 未改期望、指标库或判定；未把错误答案当零 | 尚未完成，待模型网络恢复后以 `test-small-v3` 回归全部 14 条 |
| 第 3 轮 | `artifacts/w03/test-small-v3` | 13/14 通过；唯一失败为 `monthly-paid-members-2026-08`，查询已成功但解释调用报 `MODEL_NETWORK_ERROR` | 模型网络瞬时中断，不是意图、SQL、数据或判定差异 | 未改期望、指标库或判定；为普通连接/DNS 错误增加一次保持原预算和超时的有界重试 | 适配器测试 15/15；不经模型直接查询得到期望 `[6,10,47550,4,0.6666666666666666,4755.0]`；当前 `api.deepseek.com` DNS 仍不可用，待恢复后重新生成完整报告 |
