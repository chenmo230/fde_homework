with monthly_base as (
    select month_start, member_id, valid_orders, net_sales_cents
    from {{ ref('monthly') }}
),
qualified as (
    select m.month_start,
           m.member_id,
           m.valid_orders,
           m.net_sales_cents
    from monthly_base m
    where exists (
        select 1
        from {{ ref('cards') }} c
        where c.member_id = m.member_id
          and c.card_type in ('悦享年卡', '家庭季卡')
          and c.valid_from <= last_day(m.month_start)
          and c.valid_until > last_day(m.month_start)
          and (c.ended_at is null or c.ended_at > last_day(m.month_start))
    )
)
select month_start, member_id, valid_orders, net_sales_cents
from qualified