select date_trunc('month',ordered_at)::date as month_start,member_id,
count(*) as valid_orders,sum(paid_cents-refund_cents) as net_sales_cents
from {{ ref('orders') }} where status='paid' and paid_cents-refund_cents>0 group by 1,2
