with valid as (
select order_id, row_number() over (partition by member_id order by ordered_at,order_id) as valid_rank
from {{ ref('orders') }} where status='paid' and paid_cents-refund_cents>0
)
select o.*,v.valid_rank from {{ ref('orders') }} o left join valid v using(order_id)
