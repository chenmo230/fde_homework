SELECT member_id || '|' || CAST(DATE_TRUNC('month', ordered_at) AS VARCHAR) AS row_id,
       member_id,
       CAST(DATE_TRUNC('month', ordered_at) AS DATE) AS month_start,
       COUNT(DISTINCT order_id) AS valid_order_count
FROM {{ ref('orders') }}
WHERE status = 'paid' AND paid_cents - refund_cents > 0
GROUP BY member_id, DATE_TRUNC('month', ordered_at)