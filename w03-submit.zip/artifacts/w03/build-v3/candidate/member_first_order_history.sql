WITH valid_orders AS (
  SELECT order_id, member_id, ordered_at, paid_cents - refund_cents AS net_sales_cents
  FROM {{ ref('orders') }}
  WHERE status = 'paid' AND paid_cents - refund_cents > 0
), ordered AS (
  SELECT order_id, member_id, ordered_at, net_sales_cents,
         ROW_NUMBER() OVER (PARTITION BY member_id ORDER BY ordered_at, order_id) AS order_seq
  FROM valid_orders
)
SELECT order_id, member_id, ordered_at, net_sales_cents, order_seq
FROM ordered