WITH valid_orders AS (
  SELECT member_id, ordered_at
  FROM {{ ref('orders') }}
  WHERE status = 'paid' AND paid_cents - refund_cents > 0
)
SELECT member_id,
       CAST(DATE_TRUNC('month', ordered_at) AS DATE) AS month_start,
       COUNT(*) AS valid_order_count
FROM valid_orders
GROUP BY member_id, CAST(DATE_TRUNC('month', ordered_at) AS DATE)